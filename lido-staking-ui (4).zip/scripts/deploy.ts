import { ethers } from "hardhat";

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with the account:", deployer.address);

  // Deploy AdvancedWallet
  const AdvancedWallet = await ethers.getContractFactory("AdvancedWallet");
  const advancedWallet = await AdvancedWallet.deploy();
  await advancedWallet.waitForDeployment();
  const advancedWalletAddress = await advancedWallet.getAddress();
  console.log("AdvancedWallet implementation deployed to:", advancedWalletAddress);

  // Note: if you want to deploy the proxy or V2, you can do so here as well.
  // Example for proxy:
  // const WalletProxy = await ethers.getContractFactory("WalletProxy");
  // const proxy = await WalletProxy.deploy(advancedWalletAddress, deployer.address);
  // await proxy.waitForDeployment();
  // console.log("Proxy deployed to:", await proxy.getAddress());
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
