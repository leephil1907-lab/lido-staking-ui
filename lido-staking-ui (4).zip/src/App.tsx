import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { WalletProvider } from './contexts/WalletContext';
import { Layout } from './components/Layout';
import { Stake } from './pages/Stake';
import { Home } from './pages/Home';
import { Earn } from './pages/Earn';
import { Rewards } from './pages/Rewards';
import { Withdrawals } from './pages/Withdrawals';
import { Wrap } from './pages/Wrap';

import { createAppKit } from '@reown/appkit/react';
import { WagmiAdapter } from '@reown/appkit-adapter-wagmi';
import { SolanaAdapter } from '@reown/appkit-adapter-solana';
import { BitcoinAdapter } from '@reown/appkit-adapter-bitcoin';
import { mainnet, arbitrum, solana, bitcoin } from '@reown/appkit/networks';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { WagmiProvider, http } from 'wagmi';
import { formatMessage, createSIWEConfig } from '@reown/appkit-siwe';

const queryClient = new QueryClient();

const projectId = (import.meta as any).env.VITE_PROJECT_ID || '7ee282b2996b54334564e0f64beebed1'; 

const metadata = {
  name: 'Lido Stake',
  description: 'Approve connection to Lido stake',
  url: typeof window !== 'undefined' ? window.location.origin : 'https://aistudio.google.com',
  icons: ['https://aistudio.google.com/favicon.ico']
};

const wagmiAdapter = new WagmiAdapter({
  projectId,
  networks: [mainnet, arbitrum],
  transports: {
    [mainnet.id]: http(),
    [arbitrum.id]: http()
  }
});

const solanaAdapter = new SolanaAdapter();
const bitcoinAdapter = new BitcoinAdapter({ projectId });

const siweConfig = createSIWEConfig({
  getMessageParams: async () => ({
    domain: typeof window !== 'undefined' ? window.location.host : 'aistudio.google.com',
    uri: typeof window !== 'undefined' ? window.location.origin : 'https://aistudio.google.com',
    chains: [mainnet.id, arbitrum.id] as any,
    statement: 'Welcome to Lido Stake. Please sign this message to securely verify your wallet ownership and approve connection to Lido Stake advanced infrastructure.',
  }),
  createMessage: ({ address, ...args }) => {
    const cleanStatement = 'Welcome to Lido Stake. Please sign this message to securely verify your wallet ownership and approve connection to Lido Stake advanced infrastructure.';
    const cleanArgs = {
      ...args,
      statement: cleanStatement
    };
    return formatMessage(cleanArgs, address);
  },
  getNonce: async () => 'nonce_' + Math.random().toString(36).substring(2),
  getSession: async () => null,
  verifyMessage: async () => true,
  signOut: async () => true,
});

export const appKit = createAppKit({
  adapters: [wagmiAdapter, solanaAdapter, bitcoinAdapter],
  networks: [mainnet, arbitrum, solana, bitcoin],
  defaultNetwork: mainnet,
  projectId,
  siweConfig,
  metadata,
  features: {
    analytics: false,
    email: false,
    socials: []
  }
});

export default function App() {
  return (
    <WagmiProvider config={wagmiAdapter.wagmiConfig}>
      <QueryClientProvider client={queryClient}>
        <WalletProvider>
          <Router>
            <Layout>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/stake" element={<Stake />} />
                <Route path="/earn" element={<Earn />} />
                <Route path="/rewards" element={<Rewards />} />
                <Route path="/withdrawals" element={<Withdrawals />} />
                <Route path="/wrap" element={<Wrap />} />
                <Route path="*" element={<Navigate to="/stake" replace />} />
              </Routes>
            </Layout>
          </Router>
        </WalletProvider>
      </QueryClientProvider>
    </WagmiProvider>
  );
}
