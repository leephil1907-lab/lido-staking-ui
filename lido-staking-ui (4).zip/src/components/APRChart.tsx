import React from 'react';
import { RadialBarChart, RadialBar, ResponsiveContainer, PolarAngleAxis } from 'recharts';

export const APRChart: React.FC<{ apr: number }> = ({ apr }) => {
  const data = [
    { name: 'APR', value: apr, fill: '#00A3FF' }
  ];

  return (
    <div className="bg-white rounded-3xl p-6 shadow-sm border border-[#e4e8eb] mb-8">
      <h3 className="text-sm font-bold text-[#273852] mb-4">Current Staking APR</h3>
      <div className="h-40 relative">
        <ResponsiveContainer width="100%" height="100%">
          <RadialBarChart 
            cx="50%" 
            cy="100%" 
            innerRadius="70%" 
            outerRadius="100%" 
            barSize={16} 
            data={data} 
            startAngle={180} 
            endAngle={0}
          >
            <PolarAngleAxis type="number" domain={[0, 10]} angleAxisId={0} tick={false} />
            <RadialBar
              background={{ fill: '#e4e8eb' }}
              dataKey="value"
              cornerRadius={8}
            />
          </RadialBarChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex flex-col items-center justify-end pb-4 pointer-events-none">
          <div className="text-3xl font-bold text-[#00A3FF] leading-none">{apr.toFixed(2)}%</div>
          <div className="text-xs text-[#7a8aa0] font-medium mt-1">Expected Annual Yield</div>
        </div>
      </div>
    </div>
  );
};
