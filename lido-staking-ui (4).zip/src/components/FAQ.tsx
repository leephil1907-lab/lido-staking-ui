import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

export const FAQ: React.FC<{ items: FAQItem[] }> = ({ items }) => {
  const [openId, setOpenId] = useState<string | null>(null);

  return (
    <div className="mt-8">
      <h3 className="text-xl font-bold text-[#273852] mb-4 dark:text-white">FAQ</h3>
      <div className="space-y-3">
        {items.map((item) => (
          <div key={item.id} className="bg-white border border-[#e4e8eb] rounded-2xl overflow-hidden dark:bg-[#1e2532] dark:border-[#334155]">
            <button
              onClick={() => setOpenId(openId === item.id ? null : item.id)}
              className="w-full px-5 py-4 flex items-center justify-between text-left"
            >
              <span className="font-semibold text-[#273852] dark:text-white">{item.question}</span>
              <ChevronDown className={`w-5 h-5 text-[#7a8aa0] transition-transform ${openId === item.id ? 'rotate-180' : ''}`} />
            </button>
            <AnimatePresence>
              {openId === item.id && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="px-5 pb-4 text-[#7a8aa0] text-sm dark:text-[#a1abbd]"
                >
                  {item.answer}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  );
};
