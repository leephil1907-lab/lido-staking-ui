import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Sun, Moon, Zap, Archive, TrendingUp, Box, ArrowDownCircle, Copy, AlertTriangle, Activity, ShieldCheck } from 'lucide-react';
import { useWallet } from '../contexts/WalletContext';
import { motion, AnimatePresence } from 'framer-motion';

import { useTokenPrice } from '../hooks/useTokenPrice';

export const Layout: React.FC<{children: React.ReactNode}> = ({ children }) => {
  const { isConnected, address, toggleWalletWorkflow, showToast, chainId } = useWallet();
  const location = useLocation();
  const { stethEthRatio, isLoading, latency, status } = useTokenPrice();

  const [isDark, setIsDark] = useState(() => {
    const saved = localStorage.getItem('theme');
    if (saved) {
      return saved === 'dark';
    }
    return document.documentElement.classList.contains('dark');
  });

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDark]);

  const toggleTheme = () => {
    setIsDark(prev => {
      const next = !prev;
      setTimeout(() => {
        window.dispatchEvent(new Event('theme-changed'));
      }, 0);
      return next;
    });
  };

  useEffect(() => {
    const handleThemeChange = () => {
      setIsDark(document.documentElement.classList.contains('dark'));
    };
    window.addEventListener('theme-changed', handleThemeChange);
    return () => window.removeEventListener('theme-changed', handleThemeChange);
  }, []);

  const getNetworkInfo = () => {
    if (!isConnected) return null;
    if (chainId === 1) return { name: 'Mainnet', color: 'bg-emerald-100 text-emerald-700 border-emerald-200' };
    if (chainId === 42161) return { name: 'Arbitrum', color: 'bg-[#E3F0FF] text-[#28A0F0] border-[#BBE3FF]' };
    return { name: 'Unsupported', color: 'bg-red-100 text-red-600 border-red-200', icon: <AlertTriangle className="w-3.5 h-3.5 mr-1" /> };
  };

  const networkInfo = getNetworkInfo();

  const navLinks = [
    { name: 'Overview', path: '/', icon: Activity },
    { name: 'Stake', path: '/stake', icon: Zap },
    { name: 'Wrap', path: '/wrap', icon: Box },
    { name: 'Withdrawals', path: '/withdrawals', icon: ArrowDownCircle },
    { name: 'Rewards', path: '/rewards', icon: Archive },
    { name: 'Earn', path: '/earn', icon: TrendingUp, badge: 'NEW' }
  ];

  const formatAddress = (addr?: string) => {
    if (!addr) return '';
    return `${addr.slice(0, 5)}...${addr.slice(-4)}`;
  };

  const handleCopyAddress = (e: React.MouseEvent) => {
    if (address) {
      e.stopPropagation();
      navigator.clipboard.writeText(address);
      showToast('Address copied!');
    }
  };

  return (
    <div className="flex flex-col min-h-screen w-full bg-[#f2f4f6] text-[#273852] font-sans overflow-hidden">
      <motion.header 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="h-[72px] flex items-center justify-between px-6 shrink-0 sticky top-0 z-40 bg-[#f2f4f6]"
      >
        <div className="flex items-center gap-8">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex items-center gap-2">
              <img src="https://assets.coingecko.com/coins/images/13573/standard/Lido_DAO.png" alt="Lido" className="w-[32px] h-[32px] object-contain rounded-full" />
              <span className="font-bold text-[#273852] text-[22px] tracking-tight">lido</span>
            </div>
          </Link>
          
          <nav className="hidden md:flex items-center gap-1 bg-white rounded-full p-1 shadow-sm border border-[#e4e8eb]">
            {navLinks.map((link) => {
              const isActive = link.path === '/' ? location.pathname === '/' : location.pathname.startsWith(link.path);
              return (
                <Link 
                  key={link.path} 
                  to={link.path}
                  className={`px-4 py-2 rounded-full text-sm font-semibold transition-colors duration-200 ${isActive ? 'bg-[#f2f4f6] text-[#273852]' : 'text-[#7a8aa0] hover:text-[#273852]'}`}
                >
                  {link.name}
                </Link>
              )
            })}
          </nav>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold border border-[#e4e8eb] bg-white shadow-sm text-[#7a8aa0]">
            <div className="flex items-center gap-1.5" title={`API Status: ${status} (${latency !== null ? latency : '---'}ms)`}>
              <div className={`w-2 h-2 rounded-full ${status === 'online' ? 'bg-green-500' : status === 'degraded' ? 'bg-yellow-500' : 'bg-red-500'}`} />
              <span className="font-mono">{latency !== null ? `${latency}ms` : '---'}</span>
            </div>
            <div className="w-px h-3 bg-[#e4e8eb]"></div>
            <div className="flex items-center">
              <Activity className="w-3.5 h-3.5 mr-1.5" />
              1 stETH = {isLoading ? '...' : stethEthRatio ? stethEthRatio.toFixed(4) : '1.0000'} ETH
            </div>
          </div>
          {networkInfo && (
            <div className={`hidden sm:flex items-center px-3 py-1.5 rounded-xl text-xs font-bold border shadow-sm ${networkInfo.color} transition-colors`}>
              {networkInfo.icon || <Activity className="w-3.5 h-3.5 mr-1.5" />}
              {networkInfo.name}
            </div>
          )}
          {isConnected ? (
            <div className="flex items-center gap-2 bg-white border border-[#e4e8eb] p-1 rounded-2xl shadow-sm">
              <motion.button 
                whileHover={{ scale: 1.02 }}
                onClick={handleCopyAddress}
                className="flex items-center gap-1.5 px-3 py-1.5 hover:bg-[#f2f4f6] rounded-xl text-sm font-semibold transition-colors cursor-pointer"
                title="Copy Address"
              >
                {formatAddress(address)} <Copy className="w-3.5 h-3.5 text-[#7a8aa0]" />
              </motion.button>
              <motion.button 
                onClick={toggleWalletWorkflow}
                className="px-3 py-1.5 hover:bg-[#fee2e2] text-[#ef4444] rounded-xl text-sm font-bold transition-colors"
                title="Disconnect Wallet"
              >
                Disconnect
              </motion.button>
            </div>
          ) : (
            <motion.button 
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={toggleWalletWorkflow}
              className={`bg-[#00A3FF] hover:bg-[#0092E6] text-white px-5 py-2.5 rounded-2xl text-sm font-semibold transition-colors flex items-center gap-2 shadow-sm`}
            >
              Connect wallet
            </motion.button>
          )}
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={toggleTheme}
            className="w-10 h-10 rounded-2xl bg-white border border-[#e4e8eb] flex items-center justify-center text-[#7a8aa0] hover:text-[#273852] transition-colors shadow-sm"
          >
             {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </motion.button>
        </div>
      </motion.header>
      
      <main className="flex-1 overflow-y-auto px-4 sm:px-6 flex flex-col items-center relative">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, x: 30, y: 0 }}
            animate={{ opacity: 1, x: 0, y: 0 }}
            exit={{ opacity: 0, x: -30, y: 0 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="w-full max-w-[540px] flex flex-col pt-6 pb-[100px]"
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </main>

      <motion.nav 
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="fixed bottom-0 left-0 right-0 h-[72px] bg-white border-t border-[#e4e8eb] flex items-center justify-around px-2 z-40 pb-2 md:hidden"
      >
          {navLinks.map((link) => {
            const isActive = link.path === '/' ? location.pathname === '/' : location.pathname.startsWith(link.path);
            const Icon = link.icon;
            return (
              <Link 
                key={link.path} 
                to={link.path}
                className={`flex flex-col items-center justify-center w-full h-full relative pt-2 ${isActive ? 'text-[#00A3FF]' : 'text-[#7a8aa0] hover:text-[#273852]'}`}
              >
                <div className="relative">
                  <motion.div
                    animate={isActive ? { scale: 1.1 } : { scale: 1 }}
                  >
                    <Icon className={`w-[20px] h-[20px] mb-1`} strokeWidth={isActive ? 2.5 : 2} />
                  </motion.div>
                  {link.badge && (
                    <span className="absolute -top-1 -right-4 bg-[#ff4a4a] text-white text-[8px] font-bold px-1 rounded-sm tracking-wider">
                      {link.badge}
                    </span>
                  )}
                </div>
                <span className="text-[10px] font-semibold mt-0.5">{link.name}</span>
              </Link>
            )
          })}
      </motion.nav>
    </div>
  );
};

