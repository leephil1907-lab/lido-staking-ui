import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useWallet } from '../contexts/WalletContext';
import { CheckCircle2, Clock, ArrowUpRight, ArrowDownLeft, RefreshCcw } from 'lucide-react';

export const TransactionHistory: React.FC = () => {
  const { transactions } = useWallet();

  const getIcon = (type: string) => {
    switch (type) {
      case 'Stake':
        return <ArrowUpRight className="w-4 h-4" />;
      case 'Withdraw':
        return <ArrowDownLeft className="w-4 h-4" />;
      case 'Wrap':
      case 'Unwrap':
        return <RefreshCcw className="w-4 h-4" />;
      default:
        return <ArrowUpRight className="w-4 h-4" />;
    }
  };

  if (transactions.length === 0) {
    return null;
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="mt-8 mb-8"
    >
      <h3 className="text-[20px] font-bold text-[#273852] mb-4 dark:text-white">Transaction History</h3>
      <div className="bg-white border border-[#e4e8eb] rounded-2xl overflow-hidden shadow-sm dark:bg-[#1e2532] dark:border-[#334155]">
        <div className="max-h-[300px] overflow-y-auto w-full">
          <AnimatePresence>
            {transactions.map((tx) => (
              <motion.div
                key={tx.id}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="flex items-center justify-between p-4 border-b border-[#f2f4f6] dark:border-[#334155] last:border-b-0 hover:bg-[#f8f9fa] dark:hover:bg-[#2d3748] transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                    tx.type === 'Stake' ? 'bg-[#00A3FF]/10 text-[#00A3FF]' : 
                    tx.type === 'Withdraw' ? 'bg-[#ff4a4a]/10 text-[#ff4a4a]' :
                    'bg-[#8b5cf6]/10 text-[#8b5cf6]'
                  }`}>
                    {getIcon(tx.type)}
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[15px] font-semibold text-[#273852] dark:text-white">{tx.type}</span>
                    <span className="text-[12px] text-[#7a8aa0] dark:text-[#94a3b8]">
                      {new Date(tx.timestamp).toLocaleString(undefined, { 
                        month: 'short', 
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-1">
                  <span className="text-[15px] font-bold text-[#273852] dark:text-white">
                    {tx.amount} {tx.currency}
                  </span>
                  <div className={`flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full ${
                    tx.status === 'Confirmed' 
                      ? 'bg-[#22c55e]/10 text-[#22c55e]' 
                      : 'bg-[#f59e0b]/10 text-[#f59e0b]'
                  }`}>
                    {tx.status === 'Confirmed' ? (
                      <CheckCircle2 className="w-3 h-3" />
                    ) : (
                      <Clock className="w-3 h-3" />
                    )}
                    {tx.status}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
};
