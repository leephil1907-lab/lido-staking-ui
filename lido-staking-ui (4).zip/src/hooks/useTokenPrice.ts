import { useState, useEffect } from 'react';

interface TokenPrices {
  ethUsd: number;
  stethUsd: number;
  stethEthRatio: number;
  isLoading: boolean;
  error: string | null;
  latency: number | null;
  status: 'online' | 'offline' | 'degraded';
}

export const useTokenPrice = () => {
  const [prices, setPrices] = useState<TokenPrices>({
    ethUsd: 0,
    stethUsd: 0,
    stethEthRatio: 0,
    isLoading: true,
    error: null,
    latency: null,
    status: 'online',
  });

  useEffect(() => {
    const fetchPrices = async () => {
      const startTime = performance.now();
      try {
        const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=staked-ether,ethereum&vs_currencies=usd');
        const endTime = performance.now();
        const currentLatency = Math.round(endTime - startTime);
        
        if (!response.ok) {
          throw new Error('Failed to fetch prices');
        }
        const data = await response.json();
        
        const ethUsd = data.ethereum?.usd || 0;
        const stethUsd = data['staked-ether']?.usd || 0;
        const stethEthRatio = ethUsd > 0 ? stethUsd / ethUsd : 0;

        let status: 'online' | 'offline' | 'degraded' = 'online';
        if (currentLatency > 1500) {
          status = 'degraded';
        }

        setPrices({
          ethUsd,
          stethUsd,
          stethEthRatio,
          isLoading: false,
          error: null,
          latency: currentLatency,
          status,
        });
      } catch (err: any) {
        setPrices(prev => ({ 
          ...prev, 
          isLoading: false, 
          error: err.message, 
          status: 'offline',
          latency: null
        }));
      }
    };

    fetchPrices();
    
    // Refresh every 60 seconds
    const interval = setInterval(fetchPrices, 60000);
    return () => clearInterval(interval);
  }, []);

  return prices;
};
