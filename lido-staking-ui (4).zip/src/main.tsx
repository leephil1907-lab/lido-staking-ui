import { Buffer } from 'buffer';
if (typeof window !== 'undefined') {
  window.Buffer = window.Buffer || Buffer;
  
  // Suppress Coinbase Wallet Analytics SDK errors that break the preview
  const originalError = console.error;
  console.error = (...args) => {
    if (args[0] && typeof args[0] === 'string' && args[0].includes('Analytics SDK')) {
      return;
    }
    originalError(...args);
  };

  window.addEventListener('unhandledrejection', (event) => {
    if (
      event.reason && 
      (
        (typeof event.reason === 'string' && event.reason.includes('Analytics SDK')) ||
        (event.reason.message && event.reason.message.includes('Analytics SDK'))
      )
    ) {
      event.preventDefault();
    }
  });
  
  const originalFetch = window.fetch;
  try {
    Object.defineProperty(window, 'fetch', {
      configurable: true,
      enumerable: true,
      writable: true,
      value: async (...args: any[]) => {
        // Intercept COOP check from WalletConnect / AppKit
        if (typeof args[0] === 'string' && args[0] === window.location.href && args[1]?.method === 'HEAD') {
          return new Response(null, {
            headers: {
              'cross-origin-opener-policy': 'same-origin-allow-popups'
            }
          });
        }
        return originalFetch.apply(window, args);
      }
    });
  } catch (error) {
    console.warn('Could not override window.fetch:', error);
  }
}

import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
