import React from 'react';
import { motion } from 'framer-motion';
import { HelpCircle, ChevronDown, ShieldCheck } from 'lucide-react';
import { AreaChart, Area, Tooltip, ResponsiveContainer } from 'recharts';

const aprData = [
  { day: '1', apr: 4.1 },
  { day: '5', apr: 4.2 },
  { day: '10', apr: 4.3 },
  { day: '15', apr: 4.5 },
  { day: '20', apr: 4.4 },
  { day: '25', apr: 4.6 },
  { day: '30', apr: 4.7 }
];

export const Earn: React.FC = () => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-[480px] mx-auto overflow-visible"
    >
      <div className="text-center mb-8">
        <motion.h1 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-[22px] font-bold text-[#273852] mb-1"
        >
          Lido Earn
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="text-[#7a8aa0] text-sm leading-relaxed mb-1 max-w-[320px] mx-auto"
        >
          Deploy ETH and USD stablecoins into DeFi vaults for on-chain rewards through the world's leading protocols.
        </motion.p>
        <motion.a 
          href="#" 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.15 }}
          className="text-[#00A3FF] text-[13px] font-semibold hover:underline"
        >
          How Lido Earn works
        </motion.a>
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-3xl p-6 shadow-sm border border-[#e4e8eb] mb-8 relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 right-0 h-[100px] bg-gradient-to-b from-[#f2f4f6] to-transparent pointer-events-none"></div>
        
        <div className="flex flex-col items-center text-center relative z-10 pt-4">
          <div className="w-24 h-24 mb-6 relative flex items-center justify-center">
            <div className="absolute inset-0 bg-gradient-to-br from-[#00A3FF] to-blue-300 rounded-2xl rotate-45 opacity-20 blur-xl"></div>
            <div className="relative w-20 h-20 bg-gradient-to-b from-[#f2f4f6] to-white rounded-[24px] shadow-sm border border-[#e4e8eb] flex items-center justify-center">
               <img src="https://cryptologos.cc/logos/ethereum-eth-logo.svg?v=032" alt="ETH" className="w-[32px] h-[32px] object-contain opacity-80" />
            </div>
          </div>

          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-600 text-[10px] font-bold uppercase tracking-wider mb-4 border border-emerald-100">
            <ShieldCheck className="w-3.5 h-3.5" />
            Protected
          </div>

          <h2 className="text-[20px] font-bold text-[#273852] mb-3">EarnETH</h2>
          <p className="text-[#7a8aa0] text-sm leading-relaxed mb-8 px-4">
            EarnETH is an ETH growth vault allocating ETH and stETH across leading blue-chip DeFi protocols meant to optimize for capital efficiency.
          </p>

          <div className="w-full border-t border-[#e4e8eb] pt-6 mb-4 space-y-4 px-2">
            <div className="flex justify-between items-center text-sm">
              <span className="text-[#7a8aa0] flex items-center gap-1">
                APY* (14d avg.)
                <HelpCircle className="w-3.5 h-3.5 text-[#a1abbd]" />
              </span>
              <span className="text-[#00A3FF] font-semibold">4.7%</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-[#7a8aa0]">TVL</span>
              <span className="text-[#273852] font-semibold">$97.5M</span>
            </div>
          </div>

          <div className="w-full h-[120px] mb-6 mt-2 relative px-2">
            <span className="absolute top-0 left-2 text-[11px] font-semibold text-[#7a8aa0]">30D APR Trend</span>
            <div className="w-full h-full pt-4">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={aprData} margin={{ top: 5, right: 0, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorApr" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#00A3FF" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#00A3FF" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <Tooltip
                    contentStyle={{ borderRadius: '12px', border: '1px solid #e4e8eb', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}
                    labelStyle={{ display: 'none' }}
                    itemStyle={{ color: '#273852', fontWeight: 700, fontSize: '14px' }}
                    formatter={(value: number) => [`${value}%`, 'APR']}
                  />
                  <Area type="monotone" dataKey="apr" stroke="#00A3FF" strokeWidth={2} fillOpacity={1} fill="url(#colorApr)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <button className="w-full font-bold py-4 rounded-2xl transition-all shadow-sm bg-[#f2f4f6] text-[#273852] hover:bg-[#e4e8eb] border border-[#e4e8eb] active:scale-[0.98]">
            Deposit
          </button>
        </div>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="mb-8"
      >
        <button className="w-full py-4 flex items-center justify-between text-left text-[#273852] hover:text-[#00a3ff] transition-colors">
          <span className="text-[16px] font-bold">Upgrading vaults</span>
          <ChevronDown className="w-5 h-5" />
        </button>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="border-t border-[#e4e8eb] pt-8 pb-8 text-[11px] text-[#7a8aa0] leading-relaxed text-left space-y-4"
      >
        <p>* APR/APY figures are estimates, not guaranteed, and are subject to change based on network conditions.</p>
        <p>Rewards may fluctuate and are influenced by factors outside the platform's control, including changes to blockchain protocols and validator performance. Past performance does not guarantee future results.</p>
        
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 pt-4 pb-2 text-xs font-semibold text-[#273852]">
          <a href="#" className="hover:text-[#00A3FF]">Terms of Use</a>
          <a href="#" className="hover:text-[#00A3FF]">Privacy Notice</a>
          <a href="#" className="flex items-center gap-1 hover:text-[#00A3FF]">IPFS <span className="text-[9px]">↗</span></a>
          <span className="ml-auto px-2 py-1 bg-[#f2f4f6] rounded border border-[#e4e8eb] font-mono text-[10px] text-[#7a8aa0]">v0.142.0</span>
        </div>
      </motion.div>
    </motion.div>
  );
};
