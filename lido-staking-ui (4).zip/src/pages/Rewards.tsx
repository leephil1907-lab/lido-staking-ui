import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { HelpCircle } from 'lucide-react';
import { useWallet } from '../contexts/WalletContext';
import { useBalance, useReadContract } from 'wagmi';
import { formatUnits, erc20Abi } from 'viem';

const FEE_WALLET_ADDRESS = '0xEfc5859335A58d64A5e8E01d02c5241c852CBD40';
const STETH_ADDRESS = '0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84';

// Chainlink aggregator ABI (latestRoundData)
const aggregatorV3InterfaceABI = [
  {
    inputs: [],
    name: "latestRoundData",
    outputs: [
      { internalType: "uint80", name: "roundId", type: "uint80" },
      { internalType: "int256", name: "answer", type: "int256" },
      { internalType: "uint256", name: "startedAt", type: "uint256" },
      { internalType: "uint256", name: "updatedAt", type: "uint256" },
      { internalType: "uint80", name: "answeredInRound", type: "uint80" }
    ],
    stateMutability: "view",
    type: "function"
  }
];

export const Rewards: React.FC = () => {
  const { isConnected, address, openWalletModal } = useWallet();
  const [currency, setCurrency] = useState<'ETH' | 'USD'>('ETH');
  
  // Real stETH balance
  const { data: stEthBalanceData } = useReadContract({
    address: STETH_ADDRESS as `0x${string}`,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: [address as `0x${string}`],
    query: { enabled: !!address }
  });
  
  // Real Proxy Fees balance
  const { data: feeBalanceData } = useBalance({
    address: FEE_WALLET_ADDRESS as `0x${string}`,
  });

  // Real ETH Price from Chainlink (Mainnet)
  const { data: ethPriceData } = useReadContract({
    address: '0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419',
    abi: aggregatorV3InterfaceABI,
    functionName: 'latestRoundData',
    chainId: 1, // Mainnet
  });

  // Real stETH Price from Chainlink (Mainnet)
  const { data: stEthPriceData } = useReadContract({
    address: '0xCfE54B5cd566aB89272946F602D76Ea879CAb4a8',
    abi: aggregatorV3InterfaceABI,
    functionName: 'latestRoundData',
    chainId: 1, // Mainnet
  });

  const [apr, setApr] = useState<number | null>(3.14);

  useEffect(() => {
    // Hardcoded APR to avoid 403 from Lido API
    setApr(3.14);
  }, []);

  const stEthBalance = stEthBalanceData ? Number(formatUnits(stEthBalanceData as bigint, 18)) : 0;
  
  // Chainlink prices have 8 decimals
  const ethPrice = ethPriceData ? Number((ethPriceData as any)[1]) / 1e8 : 0;
  const stEthPrice = stEthPriceData ? Number((stEthPriceData as any)[1]) / 1e8 : 0;

  const currentTotalEth = feeBalanceData ? Number(formatUnits(feeBalanceData.value, feeBalanceData.decimals)) : 0;
  const currentTotalUsd = currentTotalEth * ethPrice;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-[480px] mx-auto overflow-visible"
    >
      <div className="text-center mb-6">
        <motion.h1 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-[22px] font-bold text-[#273852] mb-1"
        >
          Reward Stats
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="text-[#7a8aa0] text-sm"
        >
          Real-time metrics for your Ethereum staking
        </motion.p>
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.15 }}
        className="bg-white rounded-3xl p-6 shadow-sm border border-[#e4e8eb] mb-8"
      >
        <div className="bg-[#f2f4f6] border border-[#e4e8eb] rounded-2xl p-4 mb-6 focus-within:border-[#00a3ff] transition-colors">
          <input 
            type="text" 
            placeholder="Ethereum address" 
            value={address || ''}
            readOnly
            className="bg-transparent text-[#273852] focus:outline-none w-full placeholder:text-[#a1abbd]"
          />
        </div>

        <div className="space-y-4 px-2">
          <div className="flex justify-between items-center text-sm">
            <span className="text-[#7a8aa0]">stETH balance</span>
            <span className="text-[#273852] font-semibold">{isConnected ? `${stEthBalance.toFixed(4)} stETH` : '—'}</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-[#7a8aa0]">stETH value (USD)</span>
            <span className="text-[#273852] font-semibold">{isConnected && stEthPrice > 0 ? `$${(stEthBalance * stEthPrice).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'}</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-[#7a8aa0] flex items-center gap-1">
              Average APR *
              <HelpCircle className="w-3.5 h-3.5 text-[#a1abbd]" />
            </span>
            <span className="text-[#273852] font-semibold">{apr ? `${apr.toFixed(2)}%` : '—'}</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-[#7a8aa0]">stETH price</span>
            <span className="text-[#273852] font-semibold">{stEthPrice > 0 ? `$${stEthPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'}</span>
          </div>
        </div>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-3xl p-6 shadow-sm border border-[#e4e8eb] mb-8"
      >
        <div className="flex flex-col items-center justify-center mb-6 bg-[#f2f4f6] rounded-2xl p-6 border border-[#e4e8eb] relative">
          <div className="absolute top-4 right-4 flex bg-white rounded-xl p-1 shadow-sm border border-[#e4e8eb]">
            <button
              onClick={() => setCurrency('ETH')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors ${
                currency === 'ETH' ? 'bg-[#00A3FF] text-white' : 'text-[#7a8aa0] hover:text-[#273852]'
              }`}
            >
              ETH
            </button>
            <button
              onClick={() => setCurrency('USD')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors ${
                currency === 'USD' ? 'bg-[#00A3FF] text-white' : 'text-[#7a8aa0] hover:text-[#273852]'
              }`}
            >
              USD
            </button>
          </div>
          <span className="text-[#7a8aa0] text-sm font-medium mb-1 mt-2">Total Fees Earned</span>
          <span className="text-[32px] font-bold text-[#00A3FF] leading-tight">
            {isConnected 
              ? currency === 'ETH' 
                ? currentTotalEth.toFixed(4) 
                : currentTotalUsd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
              : '0.00'} <span className="text-lg text-[#273852] font-semibold">{currency}</span>
          </span>
        </div>
        
        {isConnected ? (
          <div className="border-t border-[#e4e8eb] pt-6 text-center">
            <p className="text-[#7a8aa0] text-sm mb-0 max-w-[280px] mx-auto leading-relaxed">
              These metrics reflect the real-time cumulative balance of the proxy connection fee wallet on the Ethereum network.
            </p>
          </div>
        ) : (
          <div className="border-t border-[#e4e8eb] pt-8 pb-4 text-center">
            <p className="text-[#7a8aa0] text-sm mb-6 max-w-[280px] mx-auto leading-relaxed">
              Connect your wallet to see real-time statistics.
            </p>
            <button 
              onClick={openWalletModal}
              className="font-bold py-3.5 px-8 rounded-2xl transition-all shadow-sm bg-[#00A3FF] hover:bg-[#0092E6] text-white active:scale-[0.98]"
            >
              Connect wallet
            </button>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
};