import React, { useState, useEffect } from 'react';
import { HelpCircle, ChevronDown, Loader2, Calculator, Wallet, TrendingUp } from 'lucide-react';
import { useWallet } from '../contexts/WalletContext';
import { motion } from 'framer-motion';
import { FAQ, FAQItem } from '../components/FAQ';
import { TransactionHistory } from '../components/TransactionHistory';
import { APRChart } from '../components/APRChart';
import { useReadContract, useGasPrice } from 'wagmi';
import { erc20Abi, formatUnits } from 'viem';

const STETH_ADDRESS = '0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84';

const stakeFaqs: FAQItem[] = [
  {
    id: 'faq1',
    question: 'What is Lido?',
    answer: 'Lido is a family of open-source peer-to-system software tools that enable users to mint transferable utility tokens (stETH) which receive rewards linked to Ethereum validation activities, while maintaining liquidity.'
  },
  {
    id: 'faq2',
    question: 'How does Lido work?',
    answer: 'When you stake ETH, you receive stETH tokens on a 1:1 basis. Your staked ETH is delegated to professional node operators who validate the Ethereum network. Rewards accrue to your stETH balance automatically.'
  }
];

export const Stake: React.FC = () => {
  const { isConnected, address, ethBalance, setEthBalance, openWalletModal, showToast, addTransaction, updateTransactionStatus } = useWallet();
  const [ethInput, setEthInput] = useState('');
  const [stakingStep, setStakingStep] = useState<'idle' | 'awaiting_approval' | 'awaiting_signature' | 'broadcasting'>('idle');
  const [apr, setApr] = useState<number | null>(3.14);

  const { data: gasPriceData } = useGasPrice();
  const gasPriceEth = gasPriceData ? Number(formatUnits(gasPriceData, 18)).toFixed(8) : '...';

  useEffect(() => {
    // Hardcoded APR to avoid 403 from Lido API
    setApr(3.14);
  }, []);

  const { data: stEthBalanceData } = useReadContract({
    address: STETH_ADDRESS as `0x${string}`,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: [address as `0x${string}`],
    query: { enabled: !!address }
  });

  const stEthBalance = stEthBalanceData ? Number(formatUnits(stEthBalanceData as bigint, 18)) : 0;
  
  // Calculate staked percentage for progress bar (stEth / (eth + stEth))
  const totalAssets = ethBalance + stEthBalance;
  const stakedPercentage = totalAssets > 0 ? (stEthBalance / totalAssets) * 100 : 0;

  const ethValue = parseFloat(ethInput);
  const isValidAmount = !isNaN(ethValue) && ethValue > 0;
  const isInsufficientFunds = isConnected && isValidAmount && ethValue > ethBalance;
  
  const stethOutput = isValidAmount ? ethValue.toFixed(4) : '';

  const handleMax = () => {
    if (!isConnected) {
      openWalletModal();
      return;
    }
    setEthInput(ethBalance.toFixed(4));
  };
  
  const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  const handleStake = async () => {
    if (!isConnected) {
      openWalletModal();
      return;
    }
    
    if (!isValidAmount || isInsufficientFunds) return;

    const txId = Math.random().toString(36).substring(2, 9);
    addTransaction({
      id: txId,
      type: 'Stake',
      amount: ethValue.toFixed(4),
      currency: 'ETH',
      status: 'Pending',
      timestamp: Date.now()
    });

    try {
      setStakingStep('awaiting_approval');
      showToast('Reown: Confirm token allowance request in your connected Exchange app.');
      await delay(2000);

      setStakingStep('awaiting_signature');
      showToast('Reown: Sign the staking payload on your Exchange device.');
      await delay(2500);

      setStakingStep('broadcasting');
      await delay(1500);

      const newBalance = Number((ethBalance - ethValue).toFixed(6));
      setEthBalance(newBalance);
      setEthInput('');
      updateTransactionStatus(txId, 'Confirmed');
      showToast(`Transaction settled via Reown. Staked ${ethValue} ETH.`);
    } catch (error) {
      console.error('Reown Pipeline Rejected:', error);
      showToast('Transaction rejected by Exchange user.');
    } finally {
      setStakingStep('idle');
    }
  };

  const getStakeBtnText = () => {
    if (stakingStep === 'awaiting_approval') return 'Awaiting Exchange Approval...';
    if (stakingStep === 'awaiting_signature') return 'Sign Staking Transaction...';
    if (stakingStep === 'broadcasting') return 'Broadcasting to Mempool...';
    if (!isConnected) return 'Connect wallet';
    if (!isValidAmount) return 'Connect wallet'; // Based on screenshot
    if (isInsufficientFunds) return 'Insufficient ETH balance';
    return 'Stake now';
  };

  const isStakeBtnDisabled = isConnected && (!isValidAmount || isInsufficientFunds);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-[480px] mx-auto overflow-visible"
    >
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.15 }}
        className="bg-white rounded-3xl p-6 shadow-sm border border-[#e4e8eb] mb-8"
      >
        <div className="mb-6">
          <h1 className="text-[22px] font-bold text-[#273852]">Stake ETH</h1>
          <p className="text-[#7a8aa0] text-sm mt-1">Stake any amount of ETH and earn daily staking rewards.</p>
        </div>

        {isConnected && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-[#00A3FF]/10 to-transparent border border-[#00A3FF]/20 rounded-2xl p-5 mb-6"
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-[#7a8aa0] text-xs font-medium mb-1">Your Staked Balance</p>
                <div className="flex items-end gap-2">
                  <h2 className="text-2xl font-bold text-[#273852] leading-none">
                    {stEthBalance.toFixed(4)}
                  </h2>
                  <span className="text-sm font-semibold text-[#00A3FF] mb-[2px]">stETH</span>
                </div>
              </div>
              <div className="bg-white rounded-xl px-3 py-1.5 shadow-sm border border-[#e4e8eb] flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-[#00bd6a]" />
                <span className="text-[#00bd6a] text-xs font-bold">{apr ? `${apr.toFixed(2)}% APR` : '...'}</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-medium mb-1.5">
                <span className="text-[#7a8aa0]">Portfolio staked</span>
                <span className="text-[#273852]">{stakedPercentage.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-white/60 h-2.5 rounded-full overflow-hidden border border-[#e4e8eb]/50">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${stakedPercentage}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className="bg-[#00A3FF] h-full rounded-full"
                />
              </div>
            </div>
          </motion.div>
        )}

        <div className="bg-[#f2f4f6] rounded-2xl p-4 mb-4 border border-[#e4e8eb] focus-within:border-[#00a3ff] transition-colors">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shrink-0 border border-[#e4e8eb] shadow-sm">
               <img src="https://cryptologos.cc/logos/ethereum-eth-logo.svg?v=032" alt="ETH" className="w-[18px] h-[18px] object-contain" />
            </div>
            <div className="flex-1 flex items-center">
              <input 
                type="number" 
                value={ethInput}
                onChange={(e) => setEthInput(e.target.value)}
                placeholder="0.0" 
                step="0.0001" 
                className="bg-transparent text-2xl font-bold text-[#273852] focus:outline-none w-full placeholder:text-[#a1abbd]"
              />
              <span className="text-xl font-bold text-[#273852] ml-2">ETH</span>
            </div>
          </div>
          <div className="flex justify-between items-center mt-3 pt-3 border-t border-[#e4e8eb]/70">
            <span className="text-xs text-[#7a8aa0] font-medium">Balance: {isConnected ? ethBalance.toFixed(4) : '0.0000'} ETH</span>
            <button onClick={handleMax} className="text-[11px] font-bold text-[#273852] bg-white px-2.5 py-1 rounded-[6px] hover:bg-slate-50 transition-colors uppercase tracking-wider border border-[#e4e8eb] shadow-sm">MAX</button>
          </div>
        </div>

        <button 
          onClick={handleStake}
          disabled={stakingStep !== 'idle' || isStakeBtnDisabled}
          className={`w-full font-bold py-4 rounded-2xl transition-all flex items-center justify-center gap-2 text-lg shadow-sm ${
            stakingStep !== 'idle' || (isConnected && isStakeBtnDisabled)
              ? 'bg-[#f2f4f6] text-[#a1abbd] cursor-not-allowed border border-[#e4e8eb]' 
              : 'bg-[#00A3FF] hover:bg-[#0092E6] text-white active:scale-[0.98]'
          }`}
        >
          {stakingStep !== 'idle' ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" /> {getStakeBtnText()}
            </>
          ) : (
            <span>{getStakeBtnText()}</span>
          )}
        </button>

        <div className="mt-8 space-y-4 px-1">
          <div className="flex justify-between items-center text-sm">
            <span className="text-[#7a8aa0]">You will receive</span>
            <div className="flex items-center gap-1.5">
              <img src="https://cryptologos.cc/logos/steth-steth-logo.svg?v=032" alt="stETH" className="w-[14px] h-[14px] object-contain" />
              <span className="text-[#273852] font-semibold">{stethOutput || '0.0'} stETH</span>
            </div>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-[#7a8aa0]">Exchange rate</span>
            <span className="text-[#273852] font-semibold">1 ETH = 1 stETH</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-[#7a8aa0]">Max transaction cost</span>
            <span className="text-[#273852] font-semibold">~$1.50</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-[#7a8aa0]">Network gas price</span>
            <span className="text-[#273852] font-semibold">{gasPriceEth} ETH</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-[#7a8aa0]">Reward fee</span>
            <span className="text-[#273852] font-semibold">10%</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-[#7a8aa0]">Lido APR</span>
            <span className="text-[#00A3FF] font-semibold">~3.2%</span>
          </div>
        </div>

        <div className="bg-[#f2f4f6] border border-[#e4e8eb] rounded-2xl p-4 mt-6">
          <div className="flex items-center gap-2 mb-3">
            <Calculator className="w-[18px] h-[18px] text-[#273852]" />
            <h3 className="text-sm font-bold text-[#273852]">Estimated Rewards</h3>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <div className="text-xs text-[#7a8aa0] mb-1 font-medium">Daily</div>
              <div className="text-sm font-bold text-[#273852]">{isValidAmount ? (ethValue * 0.032 / 365).toFixed(5) : '0.000'} <span className="text-[10px] text-[#7a8aa0]">stETH</span></div>
            </div>
            <div>
              <div className="text-xs text-[#7a8aa0] mb-1 font-medium">Monthly</div>
              <div className="text-sm font-bold text-[#273852]">{isValidAmount ? (ethValue * 0.032 / 12).toFixed(5) : '0.000'} <span className="text-[10px] text-[#7a8aa0]">stETH</span></div>
            </div>
            <div>
              <div className="text-xs text-[#7a8aa0] mb-1 font-medium">Yearly</div>
              <div className="text-sm font-bold text-[#00A3FF]">{isValidAmount ? (ethValue * 0.032).toFixed(5) : '0.000'} <span className="text-[10px] text-[#00A3FF]/70">stETH</span></div>
            </div>
          </div>
        </div>
      </motion.div>

      <APRChart apr={apr || 3.14} />

      <TransactionHistory />

      <FAQ items={stakeFaqs} />

      <div className="mt-6 mb-12 text-[#7a8aa0] text-[13px] text-center leading-relaxed px-4">
        Lido is an open-source peer-to-system software suite that enables users to mint transferable utility tokens (stETH) which receive rewards linked to Ethereum validation activities.
      </div>

    </motion.div>
  );
};
