import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useWallet } from '../contexts/WalletContext';
import { FAQ, FAQItem } from '../components/FAQ';
import { TransactionHistory } from '../components/TransactionHistory';
import { Loader2 } from 'lucide-react';

const withdrawalFaqs: FAQItem[] = [
  {
    id: 'w-faq1',
    question: 'How long do withdrawals take?',
    answer: 'Withdrawal requests normally take 1-5 days to process depending on the amount of ETH in the exit queue and Ethereum network conditions.'
  },
  {
    id: 'w-faq2',
    question: 'Are there fees for withdrawing?',
    answer: 'Lido does not charge additional fees for withdrawing, but standard Ethereum network gas fees apply when requesting and claiming your withdrawal.'
  }
];

export const Withdrawals: React.FC = () => {
  const { isConnected, openWalletModal, showToast, addTransaction, updateTransactionStatus } = useWallet();
  const [amount, setAmount] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const parsedAmount = parseFloat(amount);
  const isValid = !isNaN(parsedAmount) && parsedAmount > 0;

  const handleWithdraw = async () => {
    if (!isConnected) {
      openWalletModal();
      return;
    }
    if (!isValid) return;

    setIsSubmitting(true);
    
    const txId = Math.random().toString(36).substring(2, 9);
    addTransaction({
      id: txId,
      type: 'Withdraw',
      amount: parsedAmount.toFixed(4),
      currency: 'stETH',
      status: 'Pending',
      timestamp: Date.now()
    });

    // Simulate transaction
    setTimeout(() => {
      setIsSubmitting(false);
      updateTransactionStatus(txId, 'Confirmed');
      showToast(`Successfully requested withdrawal of ${parsedAmount} stETH. You will receive an NFT representing your request.`);
      setAmount('');
    }, 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-[480px] mx-auto overflow-visible"
    >
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.15 }}
        className="bg-white rounded-3xl p-6 shadow-sm border border-[#e4e8eb] mb-8"
      >
        <div className="mb-6">
          <h1 className="text-[22px] font-bold text-[#273852]">Request Withdrawal</h1>
          <p className="text-[#7a8aa0] text-sm mt-1">Unstake your assets from the protocol at any time.</p>
        </div>

        <div className="bg-[#f2f4f6] rounded-2xl p-4 mb-6 border border-[#e4e8eb] focus-within:border-[#00a3ff] transition-colors">
          <div className="flex items-center gap-3">
             <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shrink-0 border border-[#e4e8eb] shadow-sm">
                 <img src="https://cryptologos.cc/logos/steth-steth-logo.svg?v=032" alt="stETH" className="w-[18px] h-[18px] object-contain" />
              </div>
            <input 
              type="number" 
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.0" 
              className="bg-transparent text-2xl font-bold text-[#273852] focus:outline-none w-full placeholder:text-[#a1abbd]"
            />
             <span className="text-xl font-bold text-[#273852] ml-2">stETH</span>
          </div>
          <div className="flex justify-between items-center mt-3 pt-3 border-t border-[#e4e8eb]/70">
            <span className="text-xs text-[#7a8aa0] font-medium">Balance: {isConnected ? '0.0000' : '0.0000'} stETH</span>
            <button className="text-[11px] font-bold text-[#273852] bg-white px-2.5 py-1 rounded-[6px] hover:bg-slate-50 transition-colors uppercase tracking-wider border border-[#e4e8eb] shadow-sm">MAX</button>
          </div>
        </div>

        <button 
          onClick={handleWithdraw}
          disabled={isSubmitting || (isConnected && !isValid)}
          className={`w-full font-bold py-4 rounded-2xl transition-all flex items-center justify-center gap-2 text-lg shadow-sm ${
            isSubmitting || (isConnected && !isValid)
              ? 'bg-[#f2f4f6] text-[#a1abbd] cursor-not-allowed border border-[#e4e8eb]'
              : 'bg-[#00A3FF] hover:bg-[#0092E6] text-white active:scale-[0.98]'
          }`}
        >
          {isSubmitting ? (
            <><Loader2 className="w-5 h-5 animate-spin" /> Submitting Request...</>
          ) : (
            isConnected ? 'Request Withdrawal' : 'Connect wallet'
          )}
        </button>
      </motion.div>

      <TransactionHistory />

      <FAQ items={withdrawalFaqs} />
    </motion.div>
  );
};
