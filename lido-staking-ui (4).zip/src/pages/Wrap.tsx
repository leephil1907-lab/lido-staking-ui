import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import { useWallet } from '../contexts/WalletContext';
import { FAQ, FAQItem } from '../components/FAQ';

const wrapFaqs: FAQItem[] = [
  {
    id: 'wrap-faq1',
    question: 'What is wstETH?',
    answer: 'Wrapped stETH (wstETH) is a non-rebasing version of stETH where your balance remains constant, but the value of the token increases relative to stETH over time.'
  },
  {
    id: 'wrap-faq2',
    question: 'Why wrap stETH?',
    answer: 'Some DeFi protocols (like Uniswap or Maker) are not designed for rebasing tokens where balances change daily. Wrapping provides a stable-balance token that is broadly compatible across DeFi.'
  }
];

export const Wrap: React.FC = () => {
  const { isConnected, openWalletModal } = useWallet();
  const [activeTab, setActiveTab] = useState<'wrap' | 'unwrap'>('wrap');
  const [amount, setAmount] = useState('');

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-[480px] mx-auto overflow-visible"
    >
      <div className="flex bg-[#e4e8eb] p-1 rounded-[20px] mb-6 w-full max-w-[240px] mx-auto">
        <button 
          onClick={() => setActiveTab('wrap')}
          className={`flex-1 py-1.5 rounded-[16px] text-sm font-semibold transition-all ${activeTab === 'wrap' ? 'bg-white text-[#273852] shadow-sm' : 'text-[#7a8aa0] hover:text-[#273852]'}`}
        >
          Wrap
        </button>
        <button 
          onClick={() => setActiveTab('unwrap')}
          className={`flex-1 py-1.5 rounded-[16px] text-sm font-semibold transition-all ${activeTab === 'unwrap' ? 'bg-white text-[#273852] shadow-sm' : 'text-[#7a8aa0] hover:text-[#273852]'}`}
        >
          Unwrap
        </button>
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.15 }}
        className="bg-white rounded-3xl p-6 shadow-sm border border-[#e4e8eb] mb-8"
      >
        <div className="mb-6">
          <h1 className="text-[22px] font-bold text-[#273852]">{activeTab === 'wrap' ? 'Wrap stETH' : 'Unwrap wstETH'}</h1>
          <p className="text-[#7a8aa0] text-sm mt-1">Stable-balance {activeTab === 'wrap' ? 'stETH wrapper for DeFi.' : 'token unlocking your stETH.'}</p>
        </div>

        <div className="bg-[#f2f4f6] rounded-2xl p-4 mb-4 border border-[#e4e8eb] focus-within:border-[#00a3ff] transition-colors">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 pr-3 border-r border-[#e4e8eb] cursor-pointer hover:bg-[#e4e8eb]/50 rounded-lg py-1 px-2 -ml-2 transition-colors">
              <img src="https://cryptologos.cc/logos/steth-steth-logo.svg?v=032" alt="Token" className="w-[18px] h-[18px] object-contain" />
              <ChevronDown className="w-4 h-4 text-[#7a8aa0]" />
            </div>
            <div className="flex-1 flex items-center">
              <input 
                type="number" 
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.0" 
                step="0.0001" 
                className="bg-transparent text-2xl font-bold text-[#273852] focus:outline-none w-full placeholder:text-[#a1abbd]"
              />
              <span className="text-xl font-bold text-[#273852] ml-2">{activeTab === 'wrap' ? 'stETH' : 'wstETH'}</span>
            </div>
          </div>
          <div className="flex justify-between items-center mt-3 pt-3 border-t border-[#e4e8eb]/70">
            <span className="text-xs text-[#7a8aa0] font-medium">Balance: {isConnected ? '0.0000' : '0.0000'} {activeTab === 'wrap' ? 'stETH' : 'wstETH'}</span>
            <button className="text-[11px] font-bold text-[#273852] bg-white px-2.5 py-1 rounded-[6px] hover:bg-slate-50 transition-colors uppercase tracking-wider border border-[#e4e8eb] shadow-sm">MAX</button>
          </div>
        </div>

        <button 
          onClick={!isConnected ? openWalletModal : undefined}
          className="w-full font-bold py-4 rounded-2xl transition-all flex items-center justify-center gap-2 text-lg shadow-sm bg-[#00A3FF] hover:bg-[#0092E6] text-white active:scale-[0.98] mb-6"
        >
          {isConnected ? (activeTab === 'wrap' ? 'Wrap' : 'Unwrap') : 'Connect wallet'}
        </button>

        <div className="space-y-4 px-1">
          <div className="flex justify-between items-center text-sm">
            <span className="text-[#7a8aa0]">You will receive</span>
            <div className="flex items-center gap-1.5">
              <img src={activeTab === 'wrap' ? "https://cryptologos.cc/logos/weth-weth-logo.svg?v=032" : "https://cryptologos.cc/logos/steth-steth-logo.svg?v=032"} alt="Output Token" className="w-[14px] h-[14px] object-contain rounded-full" />
              <span className="text-[#273852] font-semibold">0.0 {activeTab === 'wrap' ? 'wstETH' : 'stETH'}</span>
            </div>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-[#7a8aa0]">Max unlock cost</span>
            <span className="text-[#273852] font-semibold">$0.00</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-[#7a8aa0]">Max transaction cost</span>
            <span className="text-[#273852] font-semibold">~$1.50</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-[#7a8aa0]">Exchange rate</span>
            <span className="text-[#273852] font-semibold">1 wstETH ≈ 1.156 stETH</span>
          </div>
        </div>
      </motion.div>

      <FAQ items={wrapFaqs} />
    </motion.div>
  );
};
