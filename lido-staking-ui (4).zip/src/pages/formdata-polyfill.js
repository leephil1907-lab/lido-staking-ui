export const FormData = typeof window !== 'undefined' ? window.FormData : global.FormData;
export const formDataToBlob = () => {};
export default typeof window !== 'undefined' ? window.FormData : global.FormData;
